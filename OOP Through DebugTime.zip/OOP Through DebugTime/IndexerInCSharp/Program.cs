﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerInCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
         
            Console.WriteLine(std[1]);

            std[0, 1] = 2;
            Console.WriteLine(std[0]);
        }
    }
}
