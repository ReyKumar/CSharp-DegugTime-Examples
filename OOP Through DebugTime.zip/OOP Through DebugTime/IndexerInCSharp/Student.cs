﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerInCSharp
{
    class Student
    {

        private int[] array = { 1,2,3,4,5};

        public int this[int index]
        {
            get
            {
                if (index >= 0 && index < array.Length)
                {
                /* return the specified index here */
                    return array[index];
                }
                else
                {
                    Console.WriteLine("Wrong Index");
                }
                return 0;

            }

            set
            {
                if (index >= 0 && index < array.Length)
                {
                    if (value > 0)
                    {
                        /* set the specified index to value here */
                        array[index] = value;
                    }
                    else
                    {
                        Console.WriteLine("Invalid Data");
                    }

                    
                }
                else
                {
                    Console.WriteLine("Wrong Index");
                }

            }
        }

        public  int this [int index, int i]
        {
            get { return array[index]; }

            set { array[index] = value + i; }
        }
    }
}
