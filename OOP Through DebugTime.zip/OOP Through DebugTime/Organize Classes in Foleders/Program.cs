﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Organize_Classes_in_Foleders.com.StudentManagement;

namespace Organize_Classes_in_Foleders
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();

            std.name = "Ronak Sankhala";
            std.age = 95;
            std.marks = 70.6F;

            std.details();
        }
    }
}
