﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Organize_Classes_in_Foleders.com.StudentManagement
{
    class Student
    {
        public string name;
        public int age;
        public float marks;

        public void details()
        {
            Console.WriteLine("Name :- {0}\nAge :- {1}\nMarks :- {2}",name,age,marks);

        }
    }
}
