﻿using InheritanceInCSharp.com.InventaryManagementSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace InheritanceInCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Clothes cloth = new Clothes();
            cloth.productID = 1;
            cloth.Name = "Jeans";
            cloth.Price = 1000;
            cloth.color = "Blue";

            Console.WriteLine("This is the Product ID :- {0}",cloth.productID);
            Console.WriteLine("Name of Cloth :- {0} \n Price Of Cloth :- {1} \n Color Of cloth :- {2}", cloth.Name, cloth.Price, cloth.color);
        }
    }
}
