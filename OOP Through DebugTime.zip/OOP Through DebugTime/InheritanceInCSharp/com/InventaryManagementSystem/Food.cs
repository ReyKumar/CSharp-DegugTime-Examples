﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceInCSharp.com.InventaryManagementSystem
{
    class Food : Product
    {
        public DateTime Exp { get; set; }
    }
}
