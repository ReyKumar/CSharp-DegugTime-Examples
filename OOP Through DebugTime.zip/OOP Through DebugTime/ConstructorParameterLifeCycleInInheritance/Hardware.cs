﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorParameterLifeCycleInInheritance
{
    class Hardware : Product 
    {
        public int size { get; set; }

        public Hardware(string n) : base(n)
        {

        }
    }
}
