﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Through_DebugTime
{
    class Student
    {
        public string name;
        public int age;
        public float marks;

        public void details()
        {
            Console.WriteLine("Name :- {0} \n Age :- {1} \n Marks :- {2}", name, age, marks);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
            std.name = "Ronak";
            std.age = 13;
            std.marks = 84.1F;

            std.details();
        }
    }
}
