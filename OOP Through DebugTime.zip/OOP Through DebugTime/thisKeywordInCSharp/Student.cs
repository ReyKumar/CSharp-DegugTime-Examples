﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace thisKeywordInCSharp
{
    class Student
    {
        private int age;
        private string name;

        public void setValues(int age, string name)
        {
            this.name = name;
            Console.Write(name);

            this.age = age;
            Console.WriteLine(age);
            
        }
    
    }
}
