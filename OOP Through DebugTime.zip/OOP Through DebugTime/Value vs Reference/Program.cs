﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Value_vs_Reference
{
    struct Student
    {
        public int age;
        public int marks;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
            std.age = 36;
            std.marks = 100;

            Student std2 = std;
            Student std3 = std;

            std.age = 12;
            std2.age = 13;

            Console.WriteLine(std.age);
            Console.WriteLine(std2.age);
            Console.WriteLine(std3.age);
            
        }
    }
}
