﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessSpecifiers1.com.StudentManagement
{
    class Student
    {
        protected int age;

    }

    class Library : Student
    {
        public void show(int a)
        {
            age = a;
            Console.WriteLine(age);
        }
    }
}
