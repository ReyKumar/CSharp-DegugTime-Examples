﻿using AccessSpecifiers1.com.StudentManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessSpecifiers1
{
    class Program
    {
        static void Main(string[] args)
        { 
            Student std = new Student();
            Library lib = new Library();

            lib.show(22);
            Console.ReadKey();
        }
    }
}
