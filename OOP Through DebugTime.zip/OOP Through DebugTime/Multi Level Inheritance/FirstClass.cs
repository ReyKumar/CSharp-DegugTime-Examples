﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Level_Inheritance
{
    class FirstClass
    {
        public void FirstFunction()
        {
            
            int a = 1;
            Console.WriteLine(a);
        }


    }
}
