﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Level_Inheritance
{
    class ThirdClass : SecondClass
    {
        public void ThirdFunction()
        {

        int c = 3;
        Console.WriteLine(c);

        }
    }
}
