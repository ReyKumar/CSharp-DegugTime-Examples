﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Level_Inheritance
{
    class SecondClass : FirstClass
    {
        public void SecondFuntion()
        {

        int b = 2;
            Console.WriteLine(b);
        }
    }
}
