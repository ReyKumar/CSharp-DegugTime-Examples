﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInCSharp
{
    class Student
    {
        public Student()
        {
            Console.WriteLine("First Code Can Run Automatically from Student");
        }
    }
}
