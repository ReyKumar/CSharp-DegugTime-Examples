﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedConstructorInCSharp
{
    class Student
    {
        private int age;

        public Student( int a )
        {
            age = a;
        }

        public void show()
        {
            Console.WriteLine("Age = {0}", age);
        }

    }
}
