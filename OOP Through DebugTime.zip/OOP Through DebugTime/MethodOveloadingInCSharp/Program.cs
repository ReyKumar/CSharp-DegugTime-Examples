﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOveloadingInCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student(22);

            std.show("My Age is ");
        }
    }
}
