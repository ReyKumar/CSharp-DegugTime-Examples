﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOveloadingInCSharp
{
    class Student
    {
        private int age;

        public Student()
        {

        }

        public Student(int a)
        {
            age = a;
        }

        public  void show()
        {
            Console.WriteLine(age);
        }

        public  void show(string msg)
        {
            Console.WriteLine(msg + age);
        }

        public void show(int  a, string msg)
        {
            Console.WriteLine(msg + age);
        }

    }
}
