﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessSpecifiers
{
    class Student
    {
        private int age;

        public void setAge(int a)
        {
            if (a>0)
            {
                age = a;
                Console.WriteLine(age);
            }

            else
            {
                Console.WriteLine("Error");
            }
            

        }


    }
}
