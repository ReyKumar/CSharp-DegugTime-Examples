﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessSpecifiers
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
            std.setAge(22);
           // std.age :- Doesn't work cause of Private Access Specifier
            Console.ReadLine();

        }
    }
}
