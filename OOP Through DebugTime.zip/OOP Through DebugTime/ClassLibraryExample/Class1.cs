﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryExample
{
    public class Person
    {
        public int age = 22;
        protected internal int marks = 87;
        internal string name ="Ronak";


    }

    public class Student : Person
    {
        public void show()
        {
            Console.WriteLine(age);
            Console.WriteLine(marks);
            Console.WriteLine(name);
        }

    }

    class other
    {
        Person per = new Person();

        public void show()
        {
            Console.WriteLine(per.age);
            Console.WriteLine(per.marks);
        }
        
    }


}
