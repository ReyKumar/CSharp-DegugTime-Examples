﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Encapsulation.com.StudentManagement
{
    class Student
    {
        private int age;
        private string name;
        private float marks;

        public void setAgeData(int a)
        {
            Console.Write("Enter the Value of Age :- ");
            a = int.Parse(Console.ReadLine());

            if (a > 0)
            {
                age = a;
            }
            else
            {
                Console.Write("You Entered invalid Age ");
            }
        }

        public void setMarks(float m)
        {
            Console.Write("Enter the Value of Marks :- ");
            m = float.Parse(Console.ReadLine());

            if (m > 0)
            {
                marks = m;
                
            }
            else
            {
                Console.WriteLine("You Entered inValid Number ");
            }
        }

        public void setName(string n)
        {
            Console.Write("Enter the Value of Name :- ");
            n = Console.ReadLine();

            if (!string.IsNullOrEmpty(n))
            {
                name = n;
            }
            else
            {
                Console.WriteLine(" You Can not Enter Null Value ");
            }
        }

        public void details()
        {
            Console.WriteLine(" \n\n Your Value is Here \n Name = {0} \n Age = {1} \n Marks = {2} ", name,age,marks);
        }
    }
}
