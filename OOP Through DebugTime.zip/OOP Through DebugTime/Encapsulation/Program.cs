﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Encapsulation.com.StudentManagement;
namespace Encapsulation
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();

            int a = 0;
            std.setAgeData(a);
            float m = 0;
            std.setMarks(m);
            string n = null;
            std.setName(n);

            std.details();
            Console.ReadLine();
        }
    }
}
