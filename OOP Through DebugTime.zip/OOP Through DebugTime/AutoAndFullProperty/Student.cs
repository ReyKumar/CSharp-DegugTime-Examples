﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoAndFullProperty
{
    class Student
    {
        public int Age { get; private set; }

    public Student(int a)
    {
            Age = a;
    }
    }

    
}
