﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoAndFullProperty
{
    class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student(22);

            Console.WriteLine(std.Age);

            Teacher tr = new Teacher();

            tr.Age = 21;
            Console.WriteLine(tr.Age);
        }
    }
}
