﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace if_else_if
{
    class Program
    {
        static void Main(string[] args)
        {
            float marks;
            string grade = "";

            Console.Write("Enter Your Marks :- ");
            marks = float.Parse(Console.ReadLine());

            if(marks > 40 && marks < 50)
            {
                grade = "C";
            }
            else if (marks >= 50 && marks < 60)
            {
                grade = "B";
            }
            else if (marks >= 60 && marks < 80)
            {
                grade = "A";
            }
            else if (marks >= 80 && marks < 100)
            {
                grade = "A+";
            }

            else if(marks < 40)
            {
                grade = "F";
            }

            Console.WriteLine("Your Grade is {0}", grade);
        }
    }
}
