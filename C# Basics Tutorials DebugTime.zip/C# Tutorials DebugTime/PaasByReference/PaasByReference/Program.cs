﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaasByReference
{
    class Program
    {
        static void Main(string[] args)
        {
            int value = 10;

            passByRef(ref value);
            Console.WriteLine("value :- {0}",value);
        }

        static void passByRef(ref int myValue)
        {
            myValue += 5;

            Console.WriteLine("MyValue :- {0}",myValue);
        }
    }
}
