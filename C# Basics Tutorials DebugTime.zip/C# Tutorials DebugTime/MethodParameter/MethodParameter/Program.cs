﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodParameter
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            Run(5, "My Name is Ronak");
            */
            Run(message: "Ronak Sankhala", count: 6);
        }

        static void Run(int count, string message)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(message);
            }
            
        }

    }
}
