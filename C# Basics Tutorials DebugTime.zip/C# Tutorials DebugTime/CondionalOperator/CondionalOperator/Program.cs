﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CondionalOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            string message = (2 < 4) ? "2 is less than 4" : "4 is less than 2";
            Console.WriteLine(message);
        }
    }
}
