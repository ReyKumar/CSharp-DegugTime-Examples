﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum_With_Switch
{
    class Program
    {
        enum Gender { Male, Female, Gay, Lesbian};
        static void Main(string[] args)
        {
            Console.Write("Your Gender :- ");
            int index = int.Parse(Console.ReadLine());

            Gender gender = (Gender)index;

            switch (gender)     
            {
                case Gender.Male:
                    Console.WriteLine("You are Male ");
                    break;

                case Gender.Female:
                    Console.WriteLine(" You are Female ");
                    break;

                case Gender.Gay:
                    Console.WriteLine("  You are Gay ");
                    break;

                case Gender.Lesbian:
                    Console.WriteLine(" You are Lesbian ");
                    break;
                default:
                    break;
            }

        }
    }
}
