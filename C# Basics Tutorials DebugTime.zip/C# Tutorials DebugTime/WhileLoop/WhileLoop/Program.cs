﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhileLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            int check = 1;

            while(check <= 5)
            {
                Console.WriteLine("Hello Ronak");
                check = check + 1; // Loop Will Infinit Without this
            }

        }
    }
}
