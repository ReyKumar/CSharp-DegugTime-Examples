﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VarAndDynamic
{
    class Program
    {
        static void Main(string[] args)
        {

            // var Keyword
            /*
            var a = 12;

            Console.WriteLine(a);
            Console.WriteLine(a.GetType());
            */

            /*
            var a = "Ronak";

            Console.WriteLine(a);
            Console.WriteLine(a.GetType());
            Console.WriteLine(a.ToUpper());
            */

            // Dynamic Keyword
            /*
            
            */

            dynamic age;
            age = 10;
            Console.WriteLine(age);
            Console.WriteLine(age.GetType());

            age = "Rey";
            Console.WriteLine(age);
            Console.WriteLine(age.GetType());
            Console.WriteLine(age.ToUpper());
        }
    }
}
