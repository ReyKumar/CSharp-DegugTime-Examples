﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCase
{
    class Program
    {
        static void Main(string[] args)
        {
            string select = "";
            Console.Write("Mithu Mia Say that Select a Number Between 1 to 3:- ");
            select = Console.ReadLine();

            switch(select)
            {
                case "1":
                    Console.WriteLine("You Will Become Succesful Developer");
                    break;

                case "2":
                    Console.WriteLine("You Will Get Rich Soon");
                    break;

                case "3":
                    Console.WriteLine("Today is Your Lucky Day");
                    break;

                default:
                    Console.WriteLine("Please Enter Correct Number ");
                    break;

            }

        }
    }
}
