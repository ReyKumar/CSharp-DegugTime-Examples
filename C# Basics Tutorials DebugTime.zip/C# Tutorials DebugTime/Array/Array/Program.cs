﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            int[] myArray = { 1,2,3,4,5 };

             Console.WriteLine(myArray); //Display Type of Array

             Console.WriteLine(myArray[3]); // display value of particular index in array
            */

            int[] myArray = new int[3];
            myArray[0] = 1;
            myArray[1] = 2;
            myArray[2] = 3;

            Console.WriteLine(myArray[1]);

        }
    }
}
