﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForEachLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = {2,5,6,4,8 };
            foreach (int item in array)
            {
                Console.WriteLine(item);
            }
        }
    }
}
