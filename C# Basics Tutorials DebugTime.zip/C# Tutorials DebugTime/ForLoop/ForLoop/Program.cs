﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            for (int check=1; check<=5; check++)
            {
                Console.WriteLine("Hello Rey");
            }
            */

            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine(i);
            }


        }
    }
}
