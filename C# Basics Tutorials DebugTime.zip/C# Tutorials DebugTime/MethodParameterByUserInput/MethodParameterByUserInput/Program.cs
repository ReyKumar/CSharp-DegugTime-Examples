﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodParameterByUserInput
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Your Message Here :- ");
            string mes = Console.ReadLine();

            Console.Write("Enter the Vale Of count :-");
            int c = int.Parse(Console.ReadLine());

            myMethod(c,mes);

        }

        static void myMethod(int count, string message)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(message);
            }
        }
    }
}
