﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassbyOut
{
    class Program
    {
        static void Main(string[] args)
        {
            int value;
               
            passByOut(out value);
            Console.WriteLine("Value :- {0}",value);
        }

        static void passByOut(out int myValue)
        {
            myValue = 10;

            Console.WriteLine("MyValue :- {0}",myValue);
        }
    }
}
