﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int check = 1;

            do
            {
                Console.WriteLine("Hello Mr Ronak");

                check = check + 1;

            } while (check <= 5);
        }
    }
}
