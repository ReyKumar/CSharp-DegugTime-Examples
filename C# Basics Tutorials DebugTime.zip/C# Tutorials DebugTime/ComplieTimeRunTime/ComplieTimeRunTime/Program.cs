﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComplieTimeRunTime
{
    class Program
    {
        static void Main(string[] args)
        {

            /* 
            int a = "20";   // Compile Time Error
            */

            /*
            int a = int.Parse("20"); // Solution of Above Statement
            Console.WriteLine(a);
            */

            int value1, value2;

            Console.WriteLine("Enter Value 1");
            value1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Value 2");
            value2 = int.Parse(Console.ReadLine());

            int result = value1 / value2;

            Console.WriteLine("the Result is {0}",result);
        }
    }
}
