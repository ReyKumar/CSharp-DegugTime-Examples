﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            * Method Syntex
            * return_type methodName (Parameter_List
            *{
            *Body Of Method
            *}
            *
            *methodName(Parameter_List); // Calling of Method
            *
            */
            papa();
            papa();
            papa();

        }
        static void papa()
        {
            Console.WriteLine("Ronak is Son Of Hansraj ji Sankhala");
            Console.WriteLine("Ronak is Son Of Hansraj ji Sankhala");
            Console.WriteLine("Ronak is Son Of Hansraj ji Sankhala");
            Console.WriteLine("Ronak is Son Of Hansraj ji Sankhala");
            Console.WriteLine("Ronak is Son Of Hansraj ji Sankhala");
        }
    }
}
