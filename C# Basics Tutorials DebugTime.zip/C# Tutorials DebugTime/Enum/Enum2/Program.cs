﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            Gender gender;

            Console.Write("Enter Your Name:- ");
            name = Console.ReadLine();

            Console.WriteLine("Choose Gender :- \n 0 For Male \n 1 For Female \n 2 For Gay \n 3 For Lesbian ");
            int index = int.Parse(Console.ReadLine());

            gender = (Gender)index;

            Console.WriteLine("Your Name is {0} and Your Gender is {1}", name,gender);


        }

        enum Gender { Male, Female , Gay, Lesbian};

        // enum Gender { Male = 5, Female , Gay, Lesbian}; // Can be use as and After 5 value Automatically increse

        // enum Gender { Male = 6, Female = 65, Gay = 4, Lesbian = 7}; // values can be assigned Manually
    }
}
