﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Ronak Sankhala";

            Gender gender = Gender.Male;

            Console.WriteLine("My Name is {0}, And I'm {1}", name,gender);
        }

        enum Gender { Male , Female, Gay, Lesbian };
    }
}
