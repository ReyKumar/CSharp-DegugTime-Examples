﻿using System;
using System.Threading;

namespace BasicFlow

{ 
    class Program
    {
        static void Main(string[] args)
        {
            // Calling a Method through Namespace
            BasicFlow.Program.run();

            //Direct Calling Method
            run();
            run();
            Console.ReadLine();
        }

        // Method Defination
        static void run() //Method Declaration
        {
            Console.WriteLine("Run Ronak Run ");
        }
    }

    public class Student
    {
       
        static void study()
        {
            Console.WriteLine(" Ram is Reading 3rd Chapter ");
        }
    }
}
